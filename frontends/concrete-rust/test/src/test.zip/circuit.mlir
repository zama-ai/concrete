module {
  func.func @dec(%arg0: !FHE.eint<6>) -> !FHE.eint<6> {
    %c1_i2 = arith.constant 1 : i2
    %0 = "FHE.to_signed"(%arg0) : (!FHE.eint<6>) -> !FHE.esint<6>
    %1 = "FHE.sub_eint_int"(%0, %c1_i2) : (!FHE.esint<6>, i2) -> !FHE.esint<6>
    %c20_i6 = arith.constant 20 : i6
    %cst = arith.constant dense<[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]> : tensor<64xi64>
    %2 = "FHE.apply_lookup_table"(%1, %cst) : (!FHE.esint<6>, tensor<64xi64>) -> !FHE.eint<6>
    return %2 : !FHE.eint<6>
  }
  func.func @inc(%arg0: !FHE.eint<6>) -> !FHE.eint<6> {
    %c1_i2 = arith.constant 1 : i2
    %0 = "FHE.add_eint_int"(%arg0, %c1_i2) : (!FHE.eint<6>, i2) -> !FHE.eint<6>
    %c20_i6 = arith.constant 20 : i6
    %c2_i7 = arith.constant 2 : i7
    %1 = "FHE.mul_eint_int"(%0, %c2_i7) : (!FHE.eint<6>, i7) -> !FHE.eint<6>
    %2 = "FHE.reinterpret_precision"(%1) : (!FHE.eint<6>) -> !FHE.eint<5>
    %cst = arith.constant dense<[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]> : tensor<32xi64>
    %3 = "FHE.apply_lookup_table"(%2, %cst) : (!FHE.eint<5>, tensor<32xi64>) -> !FHE.eint<6>
    return %3 : !FHE.eint<6>
  }
}